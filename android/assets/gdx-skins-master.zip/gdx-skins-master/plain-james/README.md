# Plain James UI

Features styles of most of **Scene2D** widgets. Simple and classy.

![Plain James](preview.png)

### About

Created with [Skin Composer](https://github.com/raeleus/skin-composer) by **Raeleus**.

### License
[CC BY 4.0](http://creativecommons.org/licenses/by/4.0/). Give credit to [***Raymond "Raeleus" Buckley***](https://ray3k.wordpress.com/software/skin-composer-for-libgdx/).
